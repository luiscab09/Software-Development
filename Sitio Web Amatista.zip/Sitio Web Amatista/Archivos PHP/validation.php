
<?php


$server = 'localhost';
$user = 'u532907816_usuarios';
$pass = 'Amatista1234$';
$db = 'u532907816_amatista';
$conectar = mysqli_connect($server,$user, $pass, $db) or die ("error en la conexion");

$email = $_POST['email'];
$pass = $_POST['password'];

$s = "select * from usuarios where email = '$email' && contraseña = '$pass'";



$result = mysqli_query($conectar,$s);

$num = mysqli_num_rows($result);

if ($num == 1){
  header('location:usuario.html');
   

}else{
  ?>
   <?php
  include("Page-6.html");
 
 
  ?>

 <h1 class= "bad" > Contraseña o Email incorrecto</h1>
  
  <?php

}





