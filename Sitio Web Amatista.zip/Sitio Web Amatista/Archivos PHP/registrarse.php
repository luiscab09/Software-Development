<?php

{
$server = 'localhost';
$user = 'u532907816_usuarios';
$pass = 'Amatista1234$';
$db = 'u532907816_amatista';
$conectar = mysqli_connect($server,$user, $pass, $db) or die ("error en la conexion");

$casa = $_POST['casa'];
$email = $_POST['email'];
$pass = $_POST['password'];

$s = "select * from usuarios where casa = '$casa' ";

$result = mysqli_query($conectar,$s);

$num = mysqli_num_rows($result);

$num = mysqli_num_rows($result);

if ($num == 1){
    ?>
   <?php
  include("Registrar.html");
 
 
  ?>

 <p class="bad">Ya existe un usuario con ese numero de Casa</p>
  
  <?php
 


}else{
    
     ?>
   <?php
  include("Registrar.html");
   ?>
   <p class="bad">Usuario Creado con Exito</p>
   <?php
   $reg = " insert into usuarios(casa , email , contraseña) values ('$casa','$email','$pass')";
    mysqli_query($conectar, $reg);
    
  

}



}

?>