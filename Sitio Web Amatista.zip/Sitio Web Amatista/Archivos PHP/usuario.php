<?php


session_start();


?>

<html>
    <head>
        <title> Amatista</title>
       


</head>

<body>
    <a href = "logout.php"> Salir </a>

<h1> Bienvenido <?php echo $_SESSION['Email']; ?> </h1>

</body>
</html>
