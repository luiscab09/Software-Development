<?php
session_start();
session_destroy();


header ('location:Page-6.html');

?>